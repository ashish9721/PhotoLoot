const Images = {
    // SPLASH_IMG: require('../Assets/bg.jpeg'),
    ICWHITEBASE: require('../Assets/Images/icWhiteBase3x.png'),
    DOLLAR: require('../Assets/Images/icDollar2x.png'),
    GOLDMEDAL: require('../Assets/Images/goldMedal.png'),
    RULESICON:require('../Assets/Images/rulesicon.png'),
    CHECKMARK:require('../Assets/Images/checkMark.png'),
    BACKBUTTON:require('../Assets/Images/backButton.png'),
    WHITEBACKIMAGE: require('../Assets/Images/whiteBackImage.png'),
    DESCRIPTIONICON: require('../Assets/Images/descriptionicon.png'),
    CLOCK:require('../Assets/Images/clock.png'),
}

export default Images;

