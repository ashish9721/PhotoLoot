const Images = {
    //SPLASH_IMG: require('../Assets/bg.jpeg'),
    LOCK:require('../Images/ChangPass.png'),
    ARROW:require('../Images/Arr.png'),
    TERMS:require('../Images/TermsCon.png'),
    FAQ:require('../Images/Faq.png'),
    ABOUT:require('../Images/AboutUs.png'),
    HELP:require('../Images/HelpNSupport.png'),
    INVITE:require('../Images/Invite.png'),
    NOTIFY:require('../Images/Notif.png'),
    SEARCH:require('../Images/ClearSearch.png'),
    DEACTIVATE:require('../Images/Deactivate.png'),
    SIGN:require('../Images/SignOut.png')
}

export default Images;

