const Images = {
    SPLASH_IMG: require('../Assets/bg.jpeg'),
}

export default Images;

