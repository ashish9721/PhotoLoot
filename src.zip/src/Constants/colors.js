export const color = {
    white:'#ffffff',
    inputTextField:'rgb(245, 245, 245)',
    placeholderText:'rgb(179,179,179)',
    gray:'gray',
    yellow:'yellow',
    lGreen:'lightgreen',
    TAndC:'rgb(255,152,3)',
    blueishGreen : 'rgb(28,123,127)',
    whiteTwo:'#f5f5f5',
    brownishGray:'rgb(96,96,96)',
    transparentColorBlack:'rgba(0,0,0,0.3)',
    lighYellow:'rgb(255,229,191)',
    questionPale:'rgb(255,240,217)'
}