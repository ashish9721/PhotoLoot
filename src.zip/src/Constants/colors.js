export const color = {
    white:'#ffffff',
    inputTextField:'rgb(245, 245, 245)',
    placeholderText:'rgb(179,179,179)',
    gray:'gray',
    yellow:'yellow',
    lGreen:'lightgreen',
    TAndC:'rgb(255,152,3)',
    blueishGreen : 'rgb(28,123,127)'
}