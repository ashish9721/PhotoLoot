import { vh, vw, DesignHeight, DesignWidth } from './Dimension';
import Strings from './strings';
// import videos from './videos'
// import images from './images'
export {
    vh,
    vw,
    DesignHeight,
    DesignWidth,
    Strings,
    // videos,
    // images,
}