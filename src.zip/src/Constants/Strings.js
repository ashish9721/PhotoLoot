const Strings = {
    hello: "Hello",
 
}

export default Strings;