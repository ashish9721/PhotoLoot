const Strings = {
    hello: "Hello",
    profileDescription:"My grandfather gave me my first camera at the age of 10 and I haven’t put it down since.",
    appreciation:"Where creativity meets appreciation",
    PhotoLoot:"PhotoLoot",
 
}

export default Strings;