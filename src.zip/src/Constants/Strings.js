const Strings = {
  hello: 'Hello',
  profileDescription:
    'My grandfather gave me my first camera at the age of 10 and I haven’t put it down since.',
  appreciation: 'Where creativity meets appreciation',
  PhotoLoot: 'PhotoLoot',
  VERIFYTEXT:
    'Your details have been verified successfully. Welcome to PhotoLoot app.',
};

export default Strings;
