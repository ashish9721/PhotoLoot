import React from 'react';
import NavTabBar from './galleryNavBar';
export const Index = () => {
  return <NavTabBar />;
};
