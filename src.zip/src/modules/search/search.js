import React, { Component } from 'react'
import { Text, View } from 'react-native'
import {styles} from './styles'
export default class search extends Component {
    render() {
        return (
            <View style={styles.container}>
                <Text> Search </Text>
            </View>
        )
    }
}

