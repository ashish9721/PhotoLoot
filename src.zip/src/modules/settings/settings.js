import React, { Component } from 'react'
import { Text, StyleSheet, View } from 'react-native'

export default class Settings extends Component {
    render() {
        return (
            <View style={{backgroundColor:'lighblue',flex:1,justifyContent:'center',alignItems:'center'}}>
                <Text> Settings </Text>
            </View>
        )
    }
}

const styles = StyleSheet.create({})
