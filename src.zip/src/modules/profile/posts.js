import React, {Component} from 'react';

// Custom Imports
import { Index } from '../gallery';

export default class Posts extends Component {
  render() {
    return <Index />;
  }
}